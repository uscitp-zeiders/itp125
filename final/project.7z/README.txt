Gets Some User Input
Cleans it && Throws a bunch of errors if it is invald
Then for each component of mp3:
    Gets correct links
    Gets mp3
    Appends it to Output
    Deletes mp3
Then it ends leaving a fresh mp3 voicemail